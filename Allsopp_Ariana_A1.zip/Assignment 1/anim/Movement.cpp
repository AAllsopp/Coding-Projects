#include "Movement.h"
//#include "Hermite.h"

Movement::Movement(const std::string& name, BaseSystem* target, Hermite* path) :
	BaseSimulator(name),
	m_object(target),
	m_path(path)
{
}	// Movement

Movement::~Movement()
{
}	// Movement::~Movement

int Movement::step(double time) // called every frame
{
	// use GLM library vectors

	double a0 = 10; // Set acceleration
	double t0 = 0.0;
	double distanceNorm = 0.0;

	double dTotal = m_path->findArcLength(1.0); // Set total path distance
	double d1 = 0.1; // Set points for speed up and slow down
	double d2 = 0.9;

	double t1 = sqrt(2 * d1 / a0); // Find the time when the distance is d1(norm)

	double vm = a0 * t1; // sqrt(2 * d1 * a0) simplified

	double t2 = t1 + (d2 - d1) / vm; // Find the time when the distance is d2(norm)

	double t3 = t2 + (2.0 * (1 - d2)) / vm; // Find the end time when the distance is dTotal(norm) = 1
	double sTime = (time / 100);

	Vector pos;
	double curDistance;
	double state[7];
	m_object->getState(state); // Get the current state of the object

	pos[0] = state[0];
	pos[1] = state[1];
	pos[2] = state[2];

	curDistance = state[6] / dTotal;

	if (curDistance >= 0.0 && curDistance <= d1) { // In window to accelerate
		//accelerate
		distanceNorm = 0.5 * a0 * (sTime * sTime);
		if (std::fabs(std::fmod(time, 1.0)) < 1e-2) {
			char buffer[100];
			sprintf(buffer, "Simulation time = %f, Speed = %f", time, vm * sTime / t1);
			animTcl::OutputMessage(buffer);
		}
	}
	else if (curDistance >= d1 && curDistance <= d2) { // In window for constant speed
		distanceNorm = 0.5 * vm * t1 + vm * (sTime - t1);
		if (std::fabs(std::fmod(time, 1.0)) < 1e-2) {
			char buffer[100];
			sprintf(buffer, "Simulation time = %f, Speed = %f", time, vm);
			animTcl::OutputMessage(buffer);
		}
	}
	else if ((curDistance > d2 && curDistance <= 1.0)) { // In window to de-accelerate
		double dFactor = 1.0 - (sTime - t2) / (2 * (t3 - t2));
		double dSpeed = vm * dFactor;
		distanceNorm = (0.5 * vm * t1) + vm * (t2 - t1) + dSpeed * (sTime - t2);

		if (distanceNorm > 1.0) {
			distanceNorm = 1.0;
		}
		if (sTime >= t3) { // To stop speed going negative
			distanceNorm = 1.0;
			if (std::fabs(std::fmod(time, 1.0)) < 1e-2) {
				char buffer[100];
				double speed = vm * (1 - (sTime - t2) / (t3 - t2));
				if (speed < 0) {
					speed = 0.0;
				}
				sprintf(buffer, "Simulation time = %f, Speed = %f", time, speed);
				animTcl::OutputMessage(buffer);
			}
		}
		else {
			if (std::fabs(std::fmod(time, 1.0)) < 1e-2) {
				char buffer[100];
				sprintf(buffer, "Simulation time = %f, Speed = %f", time, vm * (1 - (sTime - t2) / (t3 - t2)));
				animTcl::OutputMessage(buffer);
			}
		}
	}
	else {
		distanceNorm = 1;
	}
	double distance = distanceNorm * dTotal; // Unnormalize distance

	if (distance > dTotal) {
		distance = dTotal;
	}

	double u = m_path->arcLengthLookup(distance); // Find u from distance
	double uSegment;
	int numKnots = m_path->getNumKnots();
	int segmentIndex = static_cast<int>(u * (numKnots - 1)); // Use the number of knots to determine the index of the segment that u falls in

	if (segmentIndex >= numKnots - 1) {
		segmentIndex = numKnots - 2; // Handle edge case at the end of the curve
		uSegment = 1.0; // If we're at the last segment, t = 1
	}
	else {
		// Calculate the local t value within the segment
		uSegment = (u * (numKnots - 1)) - segmentIndex;
	}

	// Generate the next sample point on the curve using the local t parameter
	ControlPoint location = m_path->getNextSample(m_path->getControlPoint(segmentIndex), m_path->getControlPoint(segmentIndex + 1), uSegment);

	state[0] = location.position[0]; // Update the object state
	state[1] = location.position[1];
	state[2] = location.position[2];
	state[3] = location.tangent[0];
	state[4] = location.tangent[1];
	state[5] = location.tangent[2];
	state[6] = distance;

	m_object->setState(state);

	return 0;

}	// Movement::step
