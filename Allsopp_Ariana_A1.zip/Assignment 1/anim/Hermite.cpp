#include <math.h>
#include <vector>

#include "Hermite.h"


Hermite::Hermite(const std::string& name) : BaseSystem(name) {
	double t = 0;

	arcLengthTable.resize(stepsInTable);
}

void Hermite::getState(double* p) {

}
void Hermite::setState(double* p) {

}
void Hermite::reset(double time) {

}

int Hermite::command(int argc, myCONST_SPEC char** argv) {
	if (argc < 1) {// Not enough arguments
		animTcl::OutputMessage("system %s: wrong number of params.", m_name.c_str());
		return TCL_ERROR;
	}
	else if (strcmp(argv[0], "cr") == 0) {// Catmull-Rom initialization with second-order accurate boundary conditions
		if (argc == 1) {
			// Call catmull-rom function with base case
			catmullRom(controlPoints[0], controlPoints[2], controlPoints[1], 0);

			// Every control point but the first and last
			for (int i = 1; i < numKnots - 1; i++) {
				// Call catmull-rom function for each point
				catmullRom(controlPoints[i], controlPoints[i - 1], controlPoints[i + 1], i);
			}
			// Call catmull-rom function with last case
			catmullRom(controlPoints[numKnots - 1], controlPoints[numKnots - 2], controlPoints[numKnots - 3], numKnots - 1);
			fillArcLengthTable();
		}
		else {
			animTcl::OutputMessage("Usage: cr");
			return TCL_ERROR;
		}
	}
	else if (strcmp(argv[0], "set") == 0) {// Change a position or tangent for existing point
		if (argc == 6) {
			if (atoi(argv[2]) > numKnots - 1 || atoi(argv[2]) < 0) { // Given index is out of bounds of points
				animTcl::OutputMessage("Index out of bounds");
				return TCL_ERROR;
			}
			if (strcmp(argv[1], "tangent") == 0) { // Changing tangent
				controlPoints[atoi(argv[2])].tangent[0] = std::stod(argv[3]); // Change tangent at given index to given values
				controlPoints[atoi(argv[2])].tangent[1] = std::stod(argv[4]);
				controlPoints[atoi(argv[2])].tangent[2] = std::stod(argv[5]);
				fillArcLengthTable();
			}
			else if (strcmp(argv[1], "point") == 0) { // Changing point
				controlPoints[atoi(argv[2])].position[0] = std::stod(argv[3]); // Change point at given index to given values
				controlPoints[atoi(argv[2])].position[1] = std::stod(argv[4]);
				controlPoints[atoi(argv[2])].position[2] = std::stod(argv[5]);
				fillArcLengthTable();
			}
			else { // Wrong parameters
				animTcl::OutputMessage("Usage: set <tangent or point> <index> <x y z> ");
				return TCL_ERROR;
			}
		}
		else { // Wrong number of parameters
			animTcl::OutputMessage("Usage: set <tangent or point> <index> <x y z> ");
			return TCL_ERROR;
		}
	}
	else if (strcmp(argv[0], "add") == 0) {// Add new point to end of spline
		if (argc == 8) {
			ControlPoint newPoint; // Make new point and add given values
			newPoint.position[0] = std::stod(argv[2]); // x
			newPoint.position[1] = std::stod(argv[3]); // y
			newPoint.position[2] = std::stod(argv[4]); // z
			newPoint.tangent[0] = std::stod(argv[5]); // sx
			newPoint.tangent[1] = std::stod(argv[6]); // sy
			newPoint.tangent[2] = std::stod(argv[7]); // sz

			controlPoints[numKnots] = newPoint; // Add point to end of spline and increase counter
			numKnots++;
			fillArcLengthTable();
		}
		else { // Wrong number of parameters
			animTcl::OutputMessage("Usage: add point <x y z sx sy sz>");
			return TCL_ERROR;
		}
	}
	else if (strcmp(argv[0], "getArcLength") == 0) {
		if (argc == 2 && std::stod(argv[1]) <= 1.0 && std::stod(argv[1]) >= 0.0) {
			double t = std::stod(argv[1]);
			double length = findArcLength(t); // Get the arc length at t
			char buffer[100];
			sprintf(buffer, "Arc length at t = %f: %f", t, length); // Output
			animTcl::OutputMessage(buffer);
		}
		else { // Wrong number of parameters or t is not in [0, 1]
			animTcl::OutputMessage("Usage, with 0 <= t <= 1: getArcLength <t>");
			return TCL_ERROR;
		}
	}
	else if (strcmp(argv[0], "load") == 0) { // Load file
		if (argc == 2) {
			// Reads file and adds points and tangents
			int numPoints = readFile(argv[1]);
			fillArcLengthTable();
		}
		else {
			animTcl::OutputMessage("Usage: load \"<file name>\"");
			return TCL_ERROR;
		}
	}
	else if (strcmp(argv[0], "export") == 0) {
		if (argc == 2) {
			
			exportToFile(strtok(argv[1], "#"));
		}
		else {
			animTcl::OutputMessage("Usage: export \"<file name>\"");
			return TCL_ERROR;
		}
	}

    glutPostRedisplay();
    return TCL_OK;
}

/// <summary>
/// Initializes tangents of each point as Catmull-Rom spline
/// </summary>
/// <param name="yi">The point of the tangent calculated</param>
/// <param name="prev">The previous control point on the spline, or the point after the next point if pos = 0</param>
/// <param name="next">The next control point on the spline, or the point before the previous point if pos = numKnots - 1</param>
/// <param name="pos">The index of the control point of the tangent</param>
void Hermite::catmullRom(ControlPoint& yi, ControlPoint prev, ControlPoint next, int pos) {
	if (pos == 0) { // Base case
		// so = 2(y1-y0) - (y2 - y0)/2
		yi.tangent[0] = 2.0 * (next.position[0] - yi.position[0]) - (prev.position[0] - yi.position[0]) / 2.0; // if pos = 0, prev becomes point after next
		yi.tangent[1] = 2.0 * (next.position[1] - yi.position[1]) - (prev.position[1] - yi.position[1]) / 2.0;
		yi.tangent[2] = 2.0 * (next.position[2] - yi.position[2]) - (prev.position[2] - yi.position[2]) / 2.0;
	}
	else if (pos == numKnots - 1) { // End case
		// sn = 2(yn-y(n-1)) - (yn - y(n-2))/2
		yi.tangent[0] = 2.0 * (yi.position[0] - prev.position[0]) - (yi.position[0] - next.position[0]) / 2.0; // if pos = n, prev becomes point before prev
		yi.tangent[1] = 2.0 * (yi.position[1] - prev.position[1]) - (yi.position[1] - next.position[1]) / 2.0;
		yi.tangent[2] = 2.0 * (yi.position[2] - prev.position[2]) - (yi.position[2] - next.position[2]) / 2.0;
	}
	else { // Calculate tangent for each point
		// si = (y(i+1) - y(i - 1))/2
		yi.tangent[0] = (next.position[0] - prev.position[0]) / 2.0;
		yi.tangent[1] = (next.position[1] - prev.position[1]) / 2.0;
		yi.tangent[2] = (next.position[2] - prev.position[2]) / 2.0;
	}
}

/// <summary>
/// Displays each control point
/// </summary>
/// <param name="numPoints">The number of points to display</param>
void Hermite::displayPoints(int numPoints) {
	if (numPoints != -1) {
		for (int i = 0; i < numPoints; i++) {
			displayControlPoint(controlPoints[i].position, 10.0);
		}
	}
}

/// <summary>
/// Reads inputted file and adds points and tangents
/// </summary>
/// <param name="filename">The name of the file</param>
/// <returns> Number of points in file </returns>
int Hermite::readFile(char* filename) {
	FILE* file = fopen(filename, "r");
	
	if (file == nullptr) {
		printf("Failed to open the file.\n");
		return -1;
	}
	char splineName[50];  // Store spline name and number or points
	int numPointsFile;

	// Read the spline name and the number of points
	int numMatch = fscanf(file, "%s %d", splineName, &numPointsFile);

	numKnots += numPointsFile;

	// Reading points and tangent vectors from the file
	for (int i = 0; i < numKnots; ++i) {
		float px, py, pz;  // Control point coordinates
		float sx, sy, sz;  // Tangent vector coordinates

		// Read a control point and its corresponding tangent vector
		int numMatch = fscanf(file, "%f %f %f %f %f %f", &px, &py, &pz, &sx, &sy, &sz);

		controlPoints[i].position[0] = px; // Update point positions and tangents
		controlPoints[i].position[1] = py;
		controlPoints[i].position[2] = pz;

		controlPoints[i].tangent[0] = sx;
		controlPoints[i].tangent[1] = sy;
		controlPoints[i].tangent[2] = sz;
	}
	fclose(file);
	return numPointsFile;
}

void Hermite::exportToFile(char* filename) {
	FILE* file = fopen(filename, "w");
	if (file == nullptr) {
		animTcl::OutputMessage("Error: Failed to open the file for writing.");
		return;
	}
	// Write the spline name and the number of control points (numKnots) to the file
	fprintf(file, "%s %d\n", m_name.c_str(), numKnots);

	for (int i = 0; i < numKnots; ++i) { // Loop through each control point and write its position and tangent to the file
		fprintf(file, "%f %f %f %f %f %f\n",
			controlPoints[i].position[0], controlPoints[i].position[1], controlPoints[i].position[2],
			controlPoints[i].tangent[0], controlPoints[i].tangent[1], controlPoints[i].tangent[2]);
	}
	fclose(file);
	animTcl::OutputMessage("Successfully exported to file");
}

/// <summary>
/// Fills the arc length table, happens whenever the spline is updated
/// </summary>
void Hermite::fillArcLengthTable() {
	arcLengthTable.clear();
	arcLengthTable.resize(stepsInTable);
	
	double totalLength = 0.0;
	double u = 1.0 / (stepsInTable - 1); // Step size for sampling the curve

	double t = 0.0;

	ControlPoint previousSample = getNextSample(controlPoints[0], controlPoints[1], t); // Initialize the first sample point on the curve
	int tableIndex = 0;

	for (double i = 0; i < 1.0 + u; i += u) {

		int segmentIndex = static_cast<int>(i * (numKnots - 1)); // Use the number of knots to determine the index of the segment that u falls in
		if (segmentIndex >= numKnots - 1) {
			segmentIndex = numKnots - 2; // Handle edge case at the end of the curve
			t = 1.0; // If we're at the last segment, t = 1
		}
		else {
			// Calculate the local t value within the segment
			t = (i * (numKnots - 1)) - segmentIndex;
		}

		// Generate the next sample point on the curve using the local t parameter
		ControlPoint nextSample = getNextSample(controlPoints[segmentIndex], controlPoints[segmentIndex + 1], t);

		// Compute the Euclidean distance between the previous sample and the next sample
		double segmentLength = sqrt(
			pow(nextSample.position[0] - previousSample.position[0], 2) +
			pow(nextSample.position[1] - previousSample.position[1], 2) +
			pow(nextSample.position[2] - previousSample.position[2], 2));

		totalLength += segmentLength; // Accumulate the total arc length
		
		arcLengthTable[tableIndex].u = i; // Add the current u value and total arc length to the lookup table
		arcLengthTable[tableIndex].length = totalLength;

		previousSample = nextSample; // Update the previous sample for the next iteration

		tableIndex++;
	}
}

/// <summary>
/// Computes the arc length at u based on the two nearest arc lengths in the table
/// </summary>
/// <param name="u">The parameter on the spline showing up to where the arc length should be computed</param>
/// <returns></returns>
double Hermite::findArcLength(double u) {
	int i = static_cast<int>(u * (stepsInTable - 1)); // Calculate the segment index

	if (i >= stepsInTable - 1) { // Check for the edge case when u is exactly 1
		i = stepsInTable - 2; // Set i to the second-to-last index to avoid out-of-bounds access
	}

	double distance = 0.0;
	
	if (u != arcLengthTable[i].u) { // Compute the arc length between values of u in the table
		distance = arcLengthTable[i].length + (u - arcLengthTable[i].u) / (arcLengthTable[i + 1].u - arcLengthTable[i].u) * (arcLengthTable[i + 1].length - arcLengthTable[i].length);
	}
	else {
		distance = arcLengthTable[i].length;
	}

	return distance;
}

/// <summary>
/// Looks up the given arc length and gives associated u
/// </summary>
/// <param name="length">The arc length</param>
/// <returns>the parameter u associated with given arc length</returns>
double Hermite::arcLengthLookup(double length) {
	double u;
	for (int i = 0; i < stepsInTable - 1; i++) {
		if (length > arcLengthTable[i].length) {
			if (length < arcLengthTable[i + 1].length) {
				// length between table at i and i+1
				u = arcLengthTable[i].u +
					(length - arcLengthTable[i].length) / (arcLengthTable[i + 1].length - arcLengthTable[i].length) *
					(arcLengthTable[i + 1].u - arcLengthTable[i].u);
				return u;

			}
		}
		else if (length = arcLengthTable[i].length) {
			return arcLengthTable[i].u;
		}
	}
	return 1.0;
}

/// <summary>
/// Gets the table of arc lengths
/// </summary>
/// <returns>The table of arc lengths</returns>
std::vector<Table> Hermite::getArcLengthTable() {
	return arcLengthTable;
}

/// <summary>
/// Gets the number of knots
/// </summary>
/// <returns>The number of knots</returns>
int Hermite::getNumKnots() {
	return numKnots;
}

/// <summary>
/// Gets the control point at the specified index
/// </summary>
/// <param name="index">Index of desired control point</param>
/// <returns>The control point</returns>
ControlPoint Hermite::getControlPoint(int index) {
	return controlPoints[index];
}


/// <summary>
/// Calculates the next sample point based on the two control points and t
/// </summary>
/// <param name="curPoint">The first end point for the sample range</param>
/// <param name="nextPoint">The last end point for the sample range</param>
/// <param name="t">The parameter for the blending functions</param>
/// <returns>Next sample point to generate spline</returns>
ControlPoint Hermite::getNextSample(ControlPoint curPoint, ControlPoint nextPoint, double t) {
	// Blending functions for points with given t
	float b0 = (2.0 * t * t * t) - (3.0 * t * t) + 1.0;
	float b1 = (-2.0 * t * t * t) + (3.0 * t * t);
	float b2 = (t * t * t) - (2.0 * t * t) + t;
	float b3 = (t * t * t) - (t * t);

	// Blending functions for tangents with given t
	float db0 = (6.0 * t * t) - (6.0 * t);
	float db1 = (-6.0 * t * t) + (6.0 * t);
	float db2 = (3.0 * t * t) - (4.0 * t) + 1.0;
	float db3 = (3.0 * t * t) - (2.0 * t);

	// Calculate the sample points based on the end points and blending functions
	float px = curPoint.position[0] * b0 + nextPoint.position[0] * b1 + curPoint.tangent[0] * b2 + nextPoint.tangent[0] * b3;
	float py = curPoint.position[1] * b0 + nextPoint.position[1] * b1 + curPoint.tangent[1] * b2 + nextPoint.tangent[1] * b3;
	float pz = curPoint.position[2] * b0 + nextPoint.position[2] * b1 + curPoint.tangent[2] * b2 + nextPoint.tangent[2] * b3;

	// Calculate the sample point tangents based on the end tangents and blending functions
	float tx = curPoint.position[0] * db0 + nextPoint.position[0] * db1 + curPoint.tangent[0] * db2 + nextPoint.tangent[0] * db3;
	float ty = curPoint.position[1] * db0 + nextPoint.position[1] * db1 + curPoint.tangent[1] * db2 + nextPoint.tangent[1] * db3;
	float tz = curPoint.position[2] * db0 + nextPoint.position[2] * db1 + curPoint.tangent[2] * db2 + nextPoint.tangent[2] * db3;

	ControlPoint sample;
	// Update the sample point
	sample.position[0] = px;
	sample.position[1] = py;
	sample.position[2] = pz;

	// Update the sample tangent
	sample.tangent[0] = tx;
	sample.tangent[1] = ty;
	sample.tangent[2] = tz;

	return sample;
}

/// <summary>
/// Displays a single control point given the point and radius
/// </summary>
/// <param name="p">point</param>
/// <param name="r">radius</param>
void Hermite::displayControlPoint(Vector p, float r) {
    glPointSize(r);
    glBegin(GL_POINTS);
    glVertex3dv(p);
    glEnd();
}

/// <summary>
/// Render the curve as a polyline approximation (ie draw lines between the sample points)
/// </summary>
void Hermite::displaySampledCurve(float r) {
    glLineWidth(r);
	glColor3f(1, 1, 1);

    glBegin(GL_LINE_STRIP);
	for (int i = 0; i < numKnots - 1; i++) { // Loop over every control point
		glVertex3f(controlPoints[i].position[0], controlPoints[i].position[1], controlPoints[i].position[2]);

		for (double t = 0; t < 100; t++) {
			ControlPoint nextSample = getNextSample(controlPoints[i], controlPoints[i + 1], t / 100);

			glVertex3f(nextSample.position[0], nextSample.position[1], nextSample.position[2]);
		}
	}
	glVertex3f(controlPoints[numKnots - 1].position[0], controlPoints[numKnots - 1].position[1], controlPoints[numKnots - 1].position[2]);
		
    glEnd();
}


void Hermite::display(GLenum mode) {
    glEnable(GL_LIGHTING);
    glMatrixMode(GL_MODELVIEW);
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glEnable(GL_COLOR_MATERIAL);

	glColor3f(1, 0, 0);

	// if system name (m_name.c_str()) is not objectpath?
	displayPoints(numKnots);
	displaySampledCurve(0.5);

    glPopAttrib();
}
