#ifndef MY_BEZIER_H
#define MY_BEZIER_H

#include "BaseSystem.h"
#include <shared/defs.h>
#include <util/util.h>
#include "animTcl.h"
#include <GLmodel/GLmodel.h>

#include "shared/opengl.h"


#include <vector> // can I do this?

struct ControlPoint {
	Vector position;  // The control point position
	Vector tangent;   // The tangent vector
	ControlPoint() {
		zeroVector(position); // Set position to (0, 0, 0)
		zeroVector(tangent);  // Set tangent to (0, 0, 0)
	}
};

struct Table {
	//int index;
	double u = 0.0; // Parametric entry u[i]
	double length = 0.0; // Arc length s[i]
};

class Hermite : public BaseSystem
{
public:
	Hermite(const std::string& name);
	virtual void getState(double* p);
	virtual void setState(double* p);
	void reset(double time);

	void displayControlPoint(Vector p, float r);
	void displaySampledCurve(float r);
	void display(GLenum mode = GL_RENDER);

	void catmullRom(ControlPoint& yi, ControlPoint prev, ControlPoint next, int pos);
	int readFile(char* filename);
	void exportToFile(char* filename);

	void fillArcLengthTable();
	double findArcLength(double u);
	double arcLengthLookup(double length);
	std::vector<Table> getArcLengthTable();
	int getNumKnots();
	ControlPoint getControlPoint(int index);
	ControlPoint getNextSample(ControlPoint curPoint, ControlPoint nextPoint, double t);

	void displayPoints(int numPoints);

	int command(int argc, myCONST_SPEC char** argv);

protected:
	//int numSamples = 40;
	//Vector p0, p1, p2, p3;
	int numKnots = 0;
	int stepsInTable = 101;
	ControlPoint controlPoints[40];
	std::vector<Table> arcLengthTable;
	//Vector samplePoints[40];
};
#endif
#pragma once
