#include "SampleParticle.h"

SampleParticle::SampleParticle(const std::string& name) :
	BaseSystem(name),
	m_sx(0.01f),
	m_sy(0.01f),
	m_sz(0.01f),
	m_rx(90.0f),
	m_ry(0.0f),
	m_rz(0.0f),
	m_distance(0.0)

{

	setVector(m_pos, 0, 0, 0);
	setVector(m_tan, 0, 0, 0);
	m_model.ReadOBJ("data/porsche.obj");
	//double m_distance = 0.0;

}	// SampleParticle

void SampleParticle::getState(double* p)
{

	VecCopy(p, m_pos);
	p[3] = m_tan[0];
	p[4] = m_tan[1];
	p[5] = m_tan[2];

	p[6] = m_distance;

}	// SampleParticle::getState

void SampleParticle::setState(double* p)
{

	VecCopy(m_pos, p);
	m_tan[0] = p[3];
	m_tan[1] = p[4];
	m_tan[2] = p[5];

	m_distance = p[6];

}	// SampleParticle::setState

void SampleParticle::reset(double time)
{

	setVector(m_pos, 0, 0, 0);
	m_distance = 0.0;
}	// SampleParticle::Reset


int SampleParticle::command(int argc, myCONST_SPEC char** argv)
{
	if (argc < 1)
	{
		animTcl::OutputMessage("system %s: wrong number of params.", m_name.c_str());
		return TCL_ERROR;
	}
	else if (strcmp(argv[0], "read") == 0)
	{
		if (argc == 2)
		{
			m_model.ReadOBJ(argv[1]);
			glmFacetNormals(&m_model);
			glmVertexNormals(&m_model, 90);
			return TCL_OK;
		}
		else
		{
			animTcl::OutputMessage("Usage: read <file_name>");
			return TCL_ERROR;
		}
	}
	else if (strcmp(argv[0], "scale") == 0)
	{
		if (argc == 4)
		{
			m_sx = (float)atof(argv[1]);
			m_sy = (float)atof(argv[2]);
			m_sz = (float)atof(argv[3]);
		}
		else
		{
			animTcl::OutputMessage("Usage: scale <sx> <sy> <sz> ");
			return TCL_ERROR;

		}
	}
	else if (strcmp(argv[0], "pos") == 0)
	{
		if (argc == 4)
		{
			m_pos[0] = atof(argv[1]);
			m_pos[1] = atof(argv[2]);
			m_pos[2] = atof(argv[3]);
		}
		else
		{
			animTcl::OutputMessage("Usage: pos <x> <y> <z> ");
			return TCL_ERROR;

		}
	}
	else if (strcmp(argv[0], "rotate") == 0)
	{
		if (argc == 4)
		{
			m_rx = (float)atof(argv[1]);
			m_ry = (float)atof(argv[2]);
			m_rz = (float)atof(argv[3]);
		}
		else
		{
			animTcl::OutputMessage("Usage: rotate <rx> <ry> <rz>");
			return TCL_ERROR;
		}
	}
	else if (strcmp(argv[0], "flipNormals") == 0)
	{
		flipNormals();
		return TCL_OK;

	}
	else if (strcmp(argv[0], "reset") == 0)
	{
		double p[3] = { 0,0,0 };
		setState(p);
	}

	glutPostRedisplay();
	return TCL_OK;

}	// SampleParticle::command

void SampleParticle::display(GLenum mode)
{
	glEnable(GL_LIGHTING);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix(); // pushing modelview
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glTranslated(m_pos[0], m_pos[1], m_pos[2]);

	// Define the default forward direction
	double forward[3] = { 0.0, 1.0, 0.0 };

	// Get the tangent vector magnitude
	double tangent[3] = { m_tan[0], m_tan[1], m_tan[2] };
	double magnitude = sqrt(tangent[0] * tangent[0] + tangent[1] * tangent[1] + tangent[2] * tangent[2]);

	// Handle case where tangent is zero-length
	if (magnitude > 0.0) {
		tangent[0] /= magnitude;
		tangent[1] /= magnitude;
		tangent[2] /= magnitude;
	}
	else {
		// Use the forward direction if tangent is invalid
		tangent[0] = forward[0];
		tangent[1] = forward[1];
		tangent[2] = 0.0;

	}
	// Create a quaternion representing the rotation from 'forward' to 'tangent'
	Quaternion rotation;
	rotation.rotateAxis(forward, tangent);

	// Convert the quaternion to a 4x4 rotation matrix
	float rotationMatrix[4][4];
	rotation.toMatrix(rotationMatrix);

	// Apply the rotation matrix
	glMultMatrixf(&rotationMatrix[0][0]);

	// Rotate the model so that the front is facing forwards
	glRotatef(-90.0, 1.0f, 0.0f, 0.0f);
	glRotatef(180.0, 0.0f, 0.0f, 1.0f);
	
	glScalef(m_sx, m_sy, m_sz); // hierarchecal translation slide deck

	if (m_model.numvertices > 0)
		glmDraw(&m_model, GLM_SMOOTH | GLM_MATERIAL);
	else
		glutSolidSphere(1.0, 20, 20);

	glPopMatrix();
	glPopAttrib();

}	// SampleParticle::display
