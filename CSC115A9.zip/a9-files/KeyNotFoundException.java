public class KeyNotFoundException extends Exception {

}
