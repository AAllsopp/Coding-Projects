#include "IKSimulator.h"

IKSimulator::IKSimulator( const std::string& name, BaseSystem* target, Hermite* path ):
	BaseSimulator( name ),
	m_object( target ),
	m_path(path),
	goal_t(0.0)
{
    setVector(goal_point, 0, 0, 0);
	onSpline = false;

}	// IKSimulator

IKSimulator::~IKSimulator()
{
}	// IKSimulator::~IKSimulator

/// <summary>
/// Creates translation matrix along x, y, z
/// </summary>
/// <param name="tx">x value for translation</param>
/// <param name="ty">y value for translation</param>
/// <param name="tz">z value for translation</param>
/// <returns>4D translation matrix</returns>
Eigen::Matrix4d IKSimulator::createTranslation(double tx, double ty, double tz) 
{
	Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
	T(0, 3) = tx;
	T(1, 3) = ty;
	T(2, 3) = tz;
	return T;
}

/// <summary>
/// Creates rotation matrix theta degrees around x
/// </summary>
/// <param name="theta">The degree of rotation in degrees</param>
/// <returns>4D Rotation matrix around x</returns>
Eigen::Matrix4d IKSimulator::createRotationX(double theta) 
{
	Eigen::Matrix4d rot = Eigen::Matrix4d::Identity();
	rot(1, 1) = cos(theta * (PI / 180));
	rot(1, 2) = -sin(theta * (PI / 180));
	rot(2, 1) = sin(theta * (PI / 180));
	rot(2, 2) = cos(theta * (PI / 180));
	return rot;
}

/// <summary>
/// Creates the derivative of the rotation matrix theta degrees around x
/// </summary>
/// <param name="theta">The degree of rotation in degrees</param>
/// <returns>Derivative of 4D Rotation matrix around x</returns>
Eigen::Matrix4d IKSimulator::createRotationXDerivative(double theta) 
{
	Eigen::Matrix4d rot = Eigen::Matrix4d::Zero();
	rot(1, 1) = -sin(theta * (PI / 180));
	rot(1, 2) = -cos(theta * (PI / 180));
	rot(2, 1) = cos(theta * (PI / 180));
	rot(2, 2) = -sin(theta * (PI / 180));
	return rot;
}

/// <summary>
/// Creates rotation matrix theta degrees around y
/// </summary>
/// <param name="theta">The degree of rotation in degrees</param>
/// <returns>4D Rotation matrix around y</returns>
Eigen::Matrix4d IKSimulator::createRotationY(double theta) 
{
	Eigen::Matrix4d rot = Eigen::Matrix4d::Identity();
	rot(0, 0) = cos(theta * (PI / 180));
	rot(0, 2) = sin(theta * (PI / 180));
	rot(2, 0) = -sin(theta * (PI / 180));
	rot(2, 2) = cos(theta * (PI / 180));
	return rot;
}

/// <summary>
/// Creates the derivative of the rotation matrix theta degrees around x
/// </summary>
/// <param name="theta">The degree of rotation in degrees</param>
/// <returns>Derivative of 4D Rotation matrix around y</returns>
Eigen::Matrix4d IKSimulator::createRotationYDerivative(double theta) 
{
	Eigen::Matrix4d rot = Eigen::Matrix4d::Zero();
	rot(0, 0) = -sin(theta * (PI / 180));
	rot(0, 2) = cos(theta * (PI / 180));
	rot(2, 0) = -cos(theta * (PI / 180));
	rot(2, 2) = -sin(theta * (PI / 180));
	return rot;
}

/// <summary>
/// Creates rotation matrix theta degrees around z
/// </summary>
/// <param name="theta">The degree of rotation in degrees</param>
/// <returns>4D Rotation matrix around z</returns>
Eigen::Matrix4d IKSimulator::createRotationZ(double theta) 
{
	Eigen::Matrix4d rot = Eigen::Matrix4d::Identity();
	rot(0, 0) = cos(theta * (PI / 180));
	rot(0, 1) = -sin(theta * (PI / 180));
	rot(1, 0) = sin(theta * (PI / 180));
	rot(1, 1) = cos(theta * (PI / 180));
	return rot;
}

/// <summary>
/// Creates the derivative of the rotation matrix theta degrees around x
/// </summary>
/// <param name="theta">The degree of rotation in degrees</param>
/// <returns>Derivative of 4D Rotation matrix around z</returns>
Eigen::Matrix4d IKSimulator::createRotationZDerivative(double theta) 
{
	Eigen::Matrix4d rot = Eigen::Matrix4d::Zero();
	rot(0, 0) = -sin(theta * (PI / 180));
	rot(0, 1) = -cos(theta * (PI / 180));
	rot(1, 0) = cos(theta * (PI / 180));
	rot(1, 1) = -sin(theta * (PI / 180));
	return rot;
}

/// <summary>
/// Computes a coluumn of the Jacobian matrix
/// </summary>
/// <param name="derivative">Angle that should have the derivative used</param>
/// <param name="p_hand">End effector in wrist coordinates using homogeneous coordinates</param>
/// <returns>A column of the 3x7 Jacobian matrix</returns>
Eigen::Vector3d IKSimulator::computeJacobianColumn(int derivative, const Eigen::Vector4d& p_hand)
{
	double state[11];
	m_object->getState(state);

	Vector root_pos;
	double shX_1, shY_2, shZ_3, elX_4, elY_5, wrZ_6, wrY_7;

	shX_1 = state[0]; // Store the current joint rotations
	shY_2 = state[1];
	shZ_3 = state[2];
	elX_4 = state[3];
	elY_5 = state[4];
	wrZ_6 = state[5];
	wrY_7 = state[6];

	root_pos[0] = state[7];
	root_pos[1] = state[8];
	root_pos[2] = state[9];

	Eigen::Matrix4d t_root = createTranslation(root_pos[0], root_pos[1], root_pos[2]); // Create transations for each coordinate system
	Eigen::Matrix4d t_shoulder = createTranslation(1.56, 2.34, 0);
	Eigen::Matrix4d t_elbow = createTranslation(4.2, 0, 0);
	Eigen::Matrix4d t_wrist = createTranslation(3.3, 0, 0);

	Eigen::Matrix4d rx1 = createRotationX(shX_1); // Create rotations for each theta
	Eigen::Matrix4d ry2 = createRotationY(shY_2);
	Eigen::Matrix4d rz3 = createRotationZ(shZ_3);

	Eigen::Matrix4d rx4 = createRotationX(elX_4);
	Eigen::Matrix4d ry5 = createRotationY(elY_5);

	Eigen::Matrix4d rz6 = createRotationZ(wrZ_6);
	Eigen::Matrix4d ry7 = createRotationY(wrY_7);

	switch (derivative) // Set appropriate derivative rotation matrix
	{
	case 0: break;
	case 1: rx1 = createRotationXDerivative(shX_1); break;
	case 2: ry2 = createRotationYDerivative(shY_2); break;
	case 3: rz3 = createRotationZDerivative(shZ_3); break;
	case 4: rx4 = createRotationXDerivative(elX_4); break;
	case 5: ry5 = createRotationYDerivative(elY_5); break;
	case 6: rz6 = createRotationZDerivative(wrZ_6); break;
	case 7: ry7 = createRotationYDerivative(wrY_7); break;
	}

	Eigen::Matrix4d tfull = t_root * t_shoulder * rz3 * ry2 * rx1 * t_elbow * ry5 * rx4 * t_wrist * ry7 * rz6; // Transformation to world coordinates

	Eigen::Vector4d p_world = tfull * p_hand;

	return p_world.head<3>();
}

/// <summary>
/// Computes the 3x7 Jacobian matrix
/// </summary>
/// <param name="p_hand">End effector in wrist coordinates using homogeneous coordinates</param>
/// <returns>The 3x7 Jacobian matrix based on the current joint angles</returns>
Eigen::MatrixXd IKSimulator::computeJacobian(const Eigen::Vector4d& p_hand) 
{
	Eigen::MatrixXd J(3, 7); // Initialize Jacobian matrix (3 rows for position, 7 columns for joints)

	// Compute columns of the Jacobian
	for (int i = 0; i < 7; ++i) 
	{
		// Compute the Jacobian column
		J.col(i) = computeJacobianColumn(i + 1, p_hand);
	}

	return J;
}

int IKSimulator::step(double time) // called every frame
{
	double delta_time = 0.01;
	
	// Retrieve current joint angles
	double state[11]; // State array includes joint angles and position
	m_object->getState(state);
	
	// Check if currently tracing spline or not
	double splineTest = state[10];
	if (splineTest < 0.5) 
	{
		onSpline = false;
		goal_t = 0.0;
	}
	else
	{
		onSpline = true;
	}


	Eigen::Vector4d p_hand = { 1.6, 0.0, 0.0, 1.0 }; // End effector in hand coordinates
	Eigen::MatrixXd J = computeJacobian(p_hand); // Computes 3 x 7 jacobian

	Eigen::MatrixXd JT = J.transpose(); // Used for pseudoinverse
	
	Eigen::Vector3d p_world = computeJacobianColumn(0, p_hand); // Location of end effector in world coordinates
	Eigen::Vector4d p_EE = { p_world[0], p_world[1], p_world[2], 1.0 };

	// Make sure there is a spline
	if (m_path->size() == 0)
	{
		return 0;
	}

	// Get point at start of spline
	VectorObj firstPointPath = m_path->getIntermediatePoint(0);

	Eigen::Vector4d p_target = { firstPointPath[0], firstPointPath[1], firstPointPath[2], 1 }; // First point on spline

	Eigen::Vector4d dirToSpline = p_target - p_EE; // Direction vector from end effector to first point on spline

	double totalDistance = dirToSpline.norm();

	if (totalDistance < 8e-2) 
	{
		// If the points are almost the same, end effector is on spline
		onSpline = true;
		state[10] = 1.0;
	}
	double speed = 250;

	if (!onSpline) // If end effector needs to go to start of spline
	{
		dirToSpline.normalize();

		Eigen::Vector3d velocity = speed * dirToSpline.head<3>(); // Velocity vector of end effector

		// Solve (J * JT) * beta = xdot
		Eigen::Matrix3d JJT = J * JT; // For pseudo-inverse
		Eigen::Vector3d beta = JJT.partialPivLu().solve(velocity); // Add () to call fullPivLu as a method

		Eigen::VectorXd jointVelocities = JT * beta; // 7x1 vector for joint velocities

		// Update joint angles using joint velocities
		for (int i = 0; i < 7; ++i) 
		{
			state[i] += jointVelocities[i] * delta_time; // Euler integration
		}

		// Update the system state with new joint angles
		m_object->setState(state);
	}
	else 
	{
		// If t reaches 1, set to 0.9999 to avoid hermite file issues
		if (goal_t < 1.000001 && goal_t > 1.0)
		{
			goal_t = 0.9999;
		}

		if (goal_t > 1.000001)
		{
			// t exceeds limit, end of spline reached
			onSpline = false;
			state[10] = 0.0;
			goal_t = 0.0;
			static_cast<BobSystem*>(m_object)->setReadyPose();

			return 0;
		}

		VectorObj target = m_path->getIntermediatePoint(goal_t); // Get target point on spline
		goal_point[0] = target[0];
		goal_point[1] = target[1];
		goal_point[2] = target[2];

		// Convert the spline point to an Eigen vector
		Eigen::Vector4d p_target = { goal_point[0], goal_point[1], goal_point[2], 1.0 };

		Eigen::Vector4d targetDir = p_target - p_EE; // Direction vector to target point

		if (targetDir.norm() < 8e-2) // If the end effector is at the target point
		{
			// If the points are almost the same, update next target point
			goal_t += 0.005;
			m_object->setState(state);
			return 0;
		}

		targetDir.normalize();

		Eigen::Vector3d velocity = speed * targetDir.head<3>(); // Velocity along the spline

		// Solve (J * JT) * beta = xdot
		Eigen::Matrix3d JJT = J * JT; // For pseudo-inverse
		Eigen::Vector3d beta = JJT.partialPivLu().solve(velocity); // Add () to call fullPivLu as a method

		// Compute joint velocities
		Eigen::VectorXd jointVelocities = JT * beta; // 7x1 vector for joint velocities

		// Update joint angles using joint velocities
		for (int i = 0; i < 7; ++i) 
		{
			state[i] += jointVelocities[i] * delta_time; // Euler integration
		}

		// Update the system state with new joint angles
		m_object->setState(state);
	}

	return 0;

}

int IKSimulator::command(int argc, myCONST_SPEC char** argv)
{
	if (argc < 1)
	{
		animTcl::OutputMessage("system %s: wrong number of params.", m_name.c_str());
		return TCL_ERROR;
	}
	else if (strcmp(argv[0], "read") == 0)
	{
		if (argc == 2)
		{
			m_path->loadFromFile2D(argv[1]);
			static_cast<BobSystem*>(m_object)->setReadyPose(); // Put bob in ready pose
		}
		else
		{
			animTcl::OutputMessage("Usage: read <spline name>");
			return TCL_ERROR;
		}
		return TCL_OK;

	}
	else if (strcmp(argv[0], "reset") == 0)
	{
		reset(0.0);
	}

	glutPostRedisplay();
	return TCL_OK;

}	// IKSimulator::command