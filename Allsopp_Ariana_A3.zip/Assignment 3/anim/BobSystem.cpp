#include "BobSystem.h"

BobSystem::BobSystem( const std::string& name ):
	BaseSystem( name ),
	m_sx( 1.0f ),
	m_sy( 1.0f ),
	m_sz( 1.0f ),
	m_shoulderAngles(new Joint()),
	m_elbowAngles(new Joint()),
	m_wristAngles(new Joint()),
	onSpline(0.0)
{ 
	setVector(m_rootPos, 0, -0.23, 4.75);
	
}	// BobSystem

BobSystem::~BobSystem()
{
	delete m_shoulderAngles;
	delete m_elbowAngles;
	delete m_wristAngles;
}

void BobSystem::getState( double* p )
{ 
	p[0] = m_shoulderAngles->xRotation; // Give rotations and root position
	p[1] = m_shoulderAngles->yRotation;
	p[2] = m_shoulderAngles->zRotation;
	p[3] = m_elbowAngles->xRotation;
	p[4] = m_elbowAngles->yRotation;
	p[5] = m_wristAngles->zRotation;
	p[6] = m_wristAngles->yRotation;

	p[7] = m_rootPos[0];
	p[8] = m_rootPos[1];
	p[9] = m_rootPos[2];
	p[10] = onSpline;

}	// BobSystem::getState

void BobSystem::setState( double  *p )
{ 
	m_shoulderAngles->xRotation = p[0]; // Set rotations and root position
	m_shoulderAngles->yRotation = p[1];
	m_shoulderAngles->zRotation = p[2];
	m_elbowAngles->xRotation = p[3];
	m_elbowAngles->yRotation = p[4];
	m_wristAngles->zRotation = p[5];
	m_wristAngles->yRotation = p[6];

	m_rootPos[0] = p[7];
	m_rootPos[1] = p[8];
	m_rootPos[2] = p[9];
	onSpline = p[10];

}	// BobSystem::setState

void BobSystem::reset( double time )
{ 
	setVector(m_rootPos, 0, -0.23, 4.75 );
	setReadyPose();
	onSpline = 0.0;
	
}	// BobSystem::Reset


int BobSystem::command(int argc, myCONST_SPEC char **argv)
{
	if( argc < 1 )
	{
		animTcl::OutputMessage("system %s: wrong number of params.", m_name.c_str()) ;
		return TCL_ERROR ;
	}
	else if( strcmp(argv[0], "position") == 0 )
	{
		if( argc == 4 )
		{
			m_rootPos[0] = atof(argv[1]) ;
			m_rootPos[1] = atof(argv[2]) ;
			m_rootPos[2] = atof(argv[3]) ;
		}
		else
		{
			animTcl::OutputMessage("Usage: pos <x> <y> <z> ") ;
			return TCL_ERROR ;
		}
	}
	else if( strcmp(argv[0], "reset") == 0)
	{
		double p[3] = {0,0,0} ;
		setState(p) ;
	}
    
    glutPostRedisplay() ;
	return TCL_OK ;

}	// BobSystem::command

void BobSystem::drawOffsetEllipse(float xRadius, float yRadius, float xOffset, float yOffset, int Segments)
{
	glPushMatrix();
	glTranslatef(xOffset, yOffset, 0.0f); // Translate to the center
	glScalef(xRadius, yRadius, 1.0); // Scale along X and Y axes
	GLdrawCircle(1.0, 32);  // Draw a unit circle, which is scaled into an ellipse
	glPopMatrix();
}

void BobSystem::markPoint()
{
	glPushMatrix();
	glColor3f(1.0f, 0.0f, 0.0f);
	glutSolidSphere(0.04f, 16, 16); // Draw a sphere with the given radius
	glColor3f(0.0f, 0.7f, 0.4f);
	glPopMatrix();
}

void BobSystem::setReadyPose()
{
	// Right arm
	m_shoulderAngles->xRotation = 180.0f;
	m_shoulderAngles->yRotation = -15.0f;
	m_shoulderAngles->zRotation = -70.0f;

	m_elbowAngles->xRotation = -15.0f;
	m_elbowAngles->yRotation = -60.0f;

	m_wristAngles->yRotation = -10.0f;
	m_wristAngles->zRotation = 10.0f;
	
	// Left arm
	m_shoulderAngles->xRotL = 180.0f;
	m_shoulderAngles->yRotL = 15.0f;
	m_shoulderAngles->zRotL = 70.0f;

	m_elbowAngles->xRotL = -15.0f;
	m_elbowAngles->yRotL = 60.0f;

	m_wristAngles->yRotL = 10.0f;
	m_wristAngles->zRotL = -10.0f;
}

void BobSystem::display( GLenum mode )
{
	float upperArmLength = 4.2f;
	float forearmLength = 3.3f;
	float handLength = 1.3f;
	float armWidth = 0.39f;

	float legSegLength = 3.9f;
	float footLength = 0.91f;
	float legWidth = 0.52f;

	glEnable(GL_LIGHTING) ;
	glMatrixMode(GL_MODELVIEW) ;
	glPushMatrix() ;
		glPushAttrib(GL_ALL_ATTRIB_BITS);
		glScalef(m_sx,m_sy,m_sz) ;
	glPopMatrix();
	
	// Draw Bob
	glPushMatrix();

		// Translate to root position
		glTranslatef(m_rootPos[0], m_rootPos[1], m_rootPos[2]);

		// Draw torso (root)
		glDisable(GL_LIGHTING);  // Disable lighting for a flat color
		glColor3f(0.0f, 0.7f, 0.4f);

		// Draw torso as an ellipse
		glPushMatrix(); // Save the current transformation state
			glScalef(1.95f, 3.9f, 1.0); // Scale along X and Y axes
			GLdrawCircle(1.0, 32); // Draw a unit circle, which is scaled into an ellipse
		glPopMatrix();

		glPushMatrix();
			glTranslatef(0.0f, 3.9f, 0.0f);
			markPoint(); // Mark neck
			drawOffsetEllipse(1.3f, 1.3f, 0, 1.3f, 16);
		glPopMatrix();

		// Draw left arm
		glPushMatrix();
			glTranslatef(-1.56f, 2.34f, 0.0f); // Translate to left shoulder

			markPoint(); // Mark shoulder joint

			glRotatef(m_shoulderAngles->zRotL, 0.0f, 0.0f, 1.0f); // Shoulder Z rotation
			glRotatef(m_shoulderAngles->yRotL, 0.0f, 1.0f, 0.0f); // Shoulder Y rotation
			glRotatef(m_shoulderAngles->xRotL, 1.0f, 0.0f, 0.0f); // Shoulder X rotation

			drawOffsetEllipse(upperArmLength / 2, armWidth, -upperArmLength/2, 0, 16); // Upper arm

			glTranslatef(-upperArmLength, 0.0f, 0.0f); // Translate to elbow

			markPoint(); // Mark elbow joint

			glRotatef(m_elbowAngles->yRotL, 0.0f, 1.0f, 0.0f); // Elbow Y rotation
			glRotatef(m_elbowAngles->xRotL, 1.0f, 0.0f, 0.0f); // Elbow X rotation

			drawOffsetEllipse(forearmLength / 2, armWidth, -forearmLength/2, 0, 16); // Lower arm

			glTranslatef(-forearmLength, 0.0f, 0.0f); // Translate to wrist

			markPoint(); // Mark wrist joint

			glRotatef(m_wristAngles->yRotL, 0.0f, 1.0f, 0.0f); // Wrist Y rotation
			glRotatef(m_wristAngles->zRotL, 0.0f, 0.0f, 1.0f); // Wrist Z rotation

			drawOffsetEllipse(handLength/2, armWidth, -handLength/2, 0, 16); // Hand
		
		glPopMatrix();

		// Draw right arm
		glPushMatrix();
			glTranslatef(1.56f, 2.34f, 0.0f); // Translate to left shoulder

			markPoint(); // Mark shoulder joint

			glRotatef(m_shoulderAngles->zRotation, 0.0f, 0.0f, 1.0f); // Shoulder Z rotation
			glRotatef(m_shoulderAngles->yRotation, 0.0f, 1.0f, 0.0f); // Shoulder Y rotation
			glRotatef(m_shoulderAngles->xRotation, 1.0f, 0.0f, 0.0f); // Shoulder X rotation

			drawOffsetEllipse(upperArmLength / 2, armWidth, upperArmLength / 2, 0, 16); // Upper arm

			glTranslatef(upperArmLength, 0.0f, 0.0f); // Translate to elbow

			markPoint(); // Mark elbow joint

			glRotatef(m_elbowAngles->yRotation, 0.0f, 1.0f, 0.0f); // Elbow Y rotation
			glRotatef(m_elbowAngles->xRotation, 1.0f, 0.0f, 0.0f); // Elbow X rotation
			
			drawOffsetEllipse(forearmLength / 2, armWidth, forearmLength / 2, 0, 16); // Lower arm

			glTranslatef(forearmLength, 0.0f, 0.0f); // Translate to wrist

			markPoint(); // Mark wrist joint

			glRotatef(m_wristAngles->yRotation, 0.0f, 1.0f, 0.0f); // Wrist Y rotation
			glRotatef(m_wristAngles->zRotation, 0.0f, 0.0f, 1.0f); // Wrist Z rotation
			
			drawOffsetEllipse(handLength / 2, armWidth, handLength / 2, 0, 16); // Hand

			glTranslatef(1.6f, 0.0f, 0.0f); // Translate to end effector

			glPushMatrix();
			glColor3f(0.8f, 0.0f, 0.6f);
			glutSolidSphere(0.07f, 16, 16); // Draw a sphere with the given radius
			glColor3f(0.0f, 1.0f, 0.0f);
			glPopMatrix();

		glPopMatrix();

		// Draw left leg
		glPushMatrix();
			glTranslatef(-1.3f, -2.99f, 0.0f); // Translate to left hip

			markPoint(); // Mark hip joint

			drawOffsetEllipse(legWidth, legSegLength / 2, 0, -legSegLength / 2, 16); // Upper leg

			glTranslatef(0.0f, -legSegLength, 0.0f); // Translate to knee

			markPoint(); // Mark knee joint

			drawOffsetEllipse(legWidth, legSegLength / 2, 0, -legSegLength / 2, 16); // Lower leg

			glTranslatef(0.0f, -legSegLength, 0.0f); // Translate to ankle

			markPoint(); // Mark ankle joint

			drawOffsetEllipse(legWidth, footLength / 2, 0, -footLength / 2, 16); // Foot

		glPopMatrix();

		// Draw right leg
		glPushMatrix();
			glTranslatef(1.3f, -2.99f, 0.0f); // Translate to left hip

			markPoint(); // Mark hip joint

			drawOffsetEllipse(legWidth, legSegLength / 2, 0, -legSegLength / 2, 16); // Upper leg

			glTranslatef(0.0f, -legSegLength, 0.0f); // Translate to knee

			markPoint(); // Mark knee joint

			drawOffsetEllipse(legWidth, legSegLength / 2, 0, -legSegLength / 2, 16); // Lower leg

			glTranslatef(0.0f, -legSegLength, 0.0f); // Translate to ankle

			markPoint(); // Mark ankle joint

			drawOffsetEllipse(legWidth, footLength / 2, 0, -footLength / 2, 16); // Foot

		glPopMatrix();

		glEnable(GL_LIGHTING);  // Re-enable lighting
	glPopMatrix();
	
	glPushMatrix();

		// Draw the ground plane at y = 0
		GLfloat groundSize = 12.0f;  // Define the size of the plane
		GLfloat groundHeight = -12.0f; // Define y position of the plane

		glDisable(GL_LIGHTING);  // Disable lighting for a flat color
		glColor3f(0.7f, 0.7f, 0.0f); // Set color for the ground plane

		glBegin(GL_QUADS);  // Begin quad for the ground plane
		glVertex3f(-groundSize, groundHeight, 0.0f); // Bottom-left corner
		glVertex3f(groundSize, groundHeight, 0.0f);  // Bottom-right corner
		glVertex3f(groundSize, groundHeight, groundSize);   // Top-right corner
		glVertex3f(-groundSize, groundHeight, groundSize);  // Top-left corner
		glEnd();

		glEnable(GL_LIGHTING);  // Re-enable lighting

	glPopMatrix();
	
	glPushMatrix();
		GLfloat wallSize = 12.0f;  // Size of the wall plane
		GLfloat wallZ = -0.0005f; // Z position of the wall plane

		glDisable(GL_LIGHTING);  // Disable lighting for a flat color
		glColor3f(0.98f, 0.93f, 1.0f); // Set color for the wall plane (blueish tone)

		glBegin(GL_QUADS);  // Begin quad for the wall plane
		glVertex3f(-wallSize, -wallSize, wallZ); // Bottom-left corner
		glVertex3f(wallSize, -wallSize, wallZ);  // Bottom-right corner
		glVertex3f(wallSize, wallSize, wallZ);   // Top-right corner
		glVertex3f(-wallSize, wallSize, wallZ);  // Top-left corner
		glEnd();

		glEnable(GL_LIGHTING);  // Re-enable lighting
	glPopMatrix();
	

	glPushMatrix();
	glTranslatef(0.0f, 1.0, 0.0f);
		GLfloat boardHeight = 5.0f;  // Size of the wall plane
		GLfloat boardWidth = 6.5f;  // Size of the wall plane
		GLfloat boardZ = 0.0f;      // Z position of the wall plane

		glDisable(GL_LIGHTING);  // Disable lighting for a flat color
		glColor3f(0.25f, 0.25f, 0.25f); // Set color for the board

		glBegin(GL_QUADS);  // Begin quad for the wall plane
		glVertex3f(-boardWidth, -boardHeight, boardZ); // Bottom-left corner
		glVertex3f(boardWidth, -boardHeight, boardZ);  // Bottom-right corner
		glVertex3f(boardWidth, boardHeight, boardZ);   // Top-right corner
		glVertex3f(-boardWidth, boardHeight, boardZ);  // Top-left corner
		glEnd();

		glEnable(GL_LIGHTING);  // Re-enable lighting
	glPopMatrix();
	
	
	glPopAttrib();

}	// BobSystem::display
