#ifndef MY_PARTICLE_H
#define MY_PARTICLE_H

#include "BaseSystem.h"
#include <shared/defs.h>
#include <util/util.h>
#include "animTcl.h"
#include <GLmodel/GLmodel.h>
#include "shared/opengl.h"
//#include <iostream>

struct Joint { // Struct to store joint rotations
	float xRotation;
	float yRotation;
	float zRotation;
	float xRotL;
	float yRotL;
	float zRotL;
	Joint() {
		xRotation = 0.0f;
		yRotation = 0.0f;
		zRotation = 0.0f;
		xRotL = 0.0f;
		yRotL = 0.0f;
		zRotL = 0.0f;
	}
};

class BobSystem : public BaseSystem
{ 

public:
	BobSystem( const std::string& name );
	virtual void getState( double *p );
	virtual void setState( double  *p );
	virtual ~BobSystem(); // Add destructor
	void reset( double time );

	void drawOffsetEllipse(float xRadius, float yRadius, float xOffset, float yOffset, int Segments);
	void markPoint();
	void setReadyPose();
	void display( GLenum mode = GL_RENDER );

	int command(int argc, myCONST_SPEC char **argv) ;

	//Vector m_pos;

protected:

	float m_sx;
	float m_sy;
	float m_sz;

	Vector m_rootPos;
	double onSpline;

	Joint* m_shoulderAngles; // Shoulder joint
	Joint* m_elbowAngles;    // Elbow joint
	Joint* m_wristAngles;    // Wrist joint
} ;
#endif
