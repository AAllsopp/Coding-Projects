#ifndef MY_GRAVITY_SIMULATOR_H
#define MY_GRAVITY_SIMULATOR_H

#include <GLModel/GLModel.h>
#include <shared/defs.h>
#include <util/util.h>
#include "animTcl.h"
#include "BaseSimulator.h"
#include "BaseSystem.h"
#include "Hermite.h"
#include "BobSystem.h"
#include <string>

#ifdef Success
	#undef Success
#endif
#include <Eigen/Dense>

class IKSimulator : public BaseSimulator
{
public:

	IKSimulator( const std::string& name, BaseSystem* target, Hermite* path );
	~IKSimulator();

	Eigen::Matrix4d createTranslation(double tx, double ty, double tz);
	Eigen::Matrix4d createRotationX(double theta);
	Eigen::Matrix4d createRotationXDerivative(double theta);
	Eigen::Matrix4d createRotationY(double theta);
	Eigen::Matrix4d createRotationYDerivative(double theta);
	Eigen::Matrix4d createRotationZ(double theta);
	Eigen::Matrix4d createRotationZDerivative(double theta);

	Eigen::Vector3d computeJacobianColumn(int derivative, const Eigen::Vector4d& p_hand);
	Eigen::MatrixXd IKSimulator::computeJacobian(const Eigen::Vector4d& p_hand);

	int step(double time);
	int init(double time) 
	{ 
		return 0;
	};

	int command(int argc, myCONST_SPEC char** argv);

protected:

	Vector goal_point; // current goal point for end effector
	double goal_t; // t for goal point

	BaseSystem* m_object;
	Hermite* m_path;
	bool onSpline;

};


#endif